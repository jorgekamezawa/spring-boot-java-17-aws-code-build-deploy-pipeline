package com.example.helloworld.model;

public record HelloWorld(String param1, String param2) {
}
